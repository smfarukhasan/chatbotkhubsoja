"""API dependency helpers."""
